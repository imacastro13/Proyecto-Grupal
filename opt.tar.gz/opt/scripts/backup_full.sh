#!/bin/bash

if [[ $1 == "-help" ]]; then
	echo "Archivo usado para backups"
	echo "El formato de uso es $0 ruta_origen ruta_destino"
	echo "Por ejemplo $0 /tmp/ /home/"
	exit 0
fi

if [[ $# -ne 2 ]]; then
	echo "Es necesario incluir origen y destino"
	exit 1
fi

ORIGEN=$1
DESTINO=$2

if [[ ! -d $ORIGEN ]]; then
	echo "No se encontro el directorio especificado"
	exit 2
fi

if [[ ! -d $DESTINO ]]; then
	echo "No se encontro el directorio especificado"
	exit 3
fi
BASE=$(basename $ORIGEN)
FECHA=$(date +%Y%m%d)
ARCHIVO="$DESTINO/${BASE}_bkp_${FECHA}.tar.gz"

if tar -czf $ARCHIVO -C $ORIGEN . ;then
	echo "Backup exitoso"
else
	echo "Error al hacer el backup"
	exit 4
fi
